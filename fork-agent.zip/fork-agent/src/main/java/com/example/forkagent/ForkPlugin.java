package com.example.forkagent;

public interface ForkPlugin {
    void onEnable();
    void onTick();
}
