package com.example.forkagent;

import java.util.ArrayList;
import java.util.List;

public class ForkPluginManager {
    private static final ForkPluginManager INSTANCE = new ForkPluginManager();
    public static ForkPluginManager getInstance() { return INSTANCE; }

    private final List<ForkPlugin> plugins = new ArrayList<>();

    public void registerPlugin(ForkPlugin plugin) {
        plugins.add(plugin);
        plugin.onEnable();
    }

    public void onServerTick() {
        for (ForkPlugin plugin : plugins) plugin.onTick();
    }
}
