package com.example.forkagent;

public class TickInterceptor {
    public static void intercept() {
        ForkPluginManager.getInstance().onServerTick();
    }
}
