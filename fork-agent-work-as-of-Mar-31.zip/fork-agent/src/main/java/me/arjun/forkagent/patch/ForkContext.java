package me.arjun.forkagent.patch;

import java.util.Map;

public class ForkContext {

    private final String mcVersion;
    private final Map<String, String> classMappings;

    public ForkContext(String mcVersion, Map<String, String> classMappings) {
        this.mcVersion = mcVersion;
        this.classMappings = classMappings;
    }

    public String getMcVersion() {
        return mcVersion;
    }

    public String resolve(String logicalName) {
        // e.g. "ServerLevel" -> "net.minecraft.server.level.ServerLevel"
        return classMappings.getOrDefault(logicalName, logicalName);
    }
}
