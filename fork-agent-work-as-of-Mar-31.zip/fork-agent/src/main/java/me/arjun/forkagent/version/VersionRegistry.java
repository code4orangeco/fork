package me.arjun.forkagent.version;

import java.util.HashMap;
import java.util.Map;

public final class VersionRegistry {

    private VersionRegistry() {}

    public static String detectMinecraftVersion() {
        // Super simple: read from package or system property.
        // You can improve this later by reading server brand, etc.
        Package p = Package.getPackage("net.minecraft");
        if (p != null && p.getImplementationVersion() != null) {
            return p.getImplementationVersion();
        }
        String prop = System.getProperty("minecraft.version");
        return prop != null ? prop : "unknown";
    }

    public static Map<String, String> mappingsFor(String version) {
        Map<String, String> map = new HashMap<>();

        // Example logical -> real class names.
        // You will tune these per version.
        if (version.startsWith("1.20")) {
            map.put("ServerLevel", "net.minecraft.server.level.ServerLevel");
        } else if (version.startsWith("26.1")) {
            // If Mojang renames, adjust here.
            map.put("ServerLevel", "net.minecraft.server.level.ServerLevel");
        } else {
            map.put("ServerLevel", "net.minecraft.server.level.ServerLevel");
        }

        return map;
    }
}
