package me.arjun.forkagent;

import me.arjun.forkagent.patch.ForkContext;
import me.arjun.forkagent.patch.ForkPatch;
import me.arjun.forkagent.version.VersionRegistry;

import java.lang.instrument.Instrumentation;
import java.util.ArrayList;
import java.util.List;
import java.util.ServiceLoader;

public class ForkAgent {

    public static void premain(String agentArgs, Instrumentation inst) {
        System.out.println("[ForkAgent] premain starting…");

        String version = VersionRegistry.detectMinecraftVersion();
        System.out.println("[ForkAgent] Detected Minecraft version: " + version);

        ForkContext ctx = new ForkContext(version, VersionRegistry.mappingsFor(version));

        List<ForkPatch> patches = loadPatches();
        System.out.println("[ForkAgent] Loaded " + patches.size() + " patches");

        for (ForkPatch patch : patches) {
            try {
                System.out.println("[ForkAgent] Applying patch: " + patch.name());
                patch.apply(inst, ctx);
                System.out.println("[ForkAgent] Patch applied: " + patch.name());
            } catch (Throwable t) {
                System.err.println("[ForkAgent] Patch failed: " + patch.name());
                t.printStackTrace();
            }
        }

        System.out.println("[ForkAgent] premain finished");
    }

    private static List<ForkPatch> loadPatches() {
        List<ForkPatch> list = new ArrayList<>();
        ServiceLoader<ForkPatch> loader = ServiceLoader.load(ForkPatch.class);
        for (ForkPatch patch : loader) {
            list.add(patch);
        }
        return list;
    }
}
