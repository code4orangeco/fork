package me.arjun.forkagent.patch;

import java.lang.instrument.Instrumentation;

public interface ForkPatch {
    String name();
    void apply(Instrumentation inst, ForkContext ctx) throws Exception;
}
