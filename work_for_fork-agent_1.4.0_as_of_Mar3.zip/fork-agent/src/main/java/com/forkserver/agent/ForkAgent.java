package com.forkserver.agent;

import com.forkserver.plugin.ForkPluginLoader;
import com.forkserver.plugin.ForkPluginManager;
import com.forkserver.interceptors.TickInterceptor;
import com.forkserver.interceptors.PlayerJoinInterceptor;

import java.io.File;
import java.lang.instrument.Instrumentation;

public class ForkAgent {

    public static void premain(String agentArgs, Instrumentation inst) {
        System.out.println("[ForkAgent] Starting Fork Agent...");

        // Load plugins from folder
        ForkPluginLoader loader = new ForkPluginLoader(new File("fork-plugins"));
        loader.loadPlugins();

        // Register interceptors
        inst.addTransformer(new TickInterceptor(), true);
        inst.addTransformer(new PlayerJoinInterceptor(), true);

        System.out.println("[ForkAgent] Agent initialized.");
    }
}
