package com.forkserver.plugin;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class ForkPluginLoader {

    private final File pluginFolder;

    public ForkPluginLoader(File pluginFolder) {
        this.pluginFolder = pluginFolder;
    }

    public void loadPlugins() {
        if (!pluginFolder.exists()) pluginFolder.mkdirs();

        File[] jars = pluginFolder.listFiles((dir, name) -> name.endsWith(".jar"));
        if (jars == null) return;

        for (File jar : jars) {
            try {
                JarFile jf = new JarFile(jar);
                Manifest mf = jf.getManifest();

                String mainClass = mf.getMainAttributes().getValue("Fork-Plugin-Class");
                if (mainClass == null) continue;

                URLClassLoader cl = new URLClassLoader(new URL[]{jar.toURI().toURL()});
                Class<?> clazz = cl.loadClass(mainClass);

                ForkPlugin plugin = (ForkPlugin) clazz.getDeclaredConstructor().newInstance();

                ForkPluginDescription desc = new ForkPluginDescription(
                        mf.getMainAttributes().getValue("Fork-Plugin-Name"),
                        mf.getMainAttributes().getValue("Fork-Plugin-Version"),
                        mf.getMainAttributes().getValue("Fork-Plugin-Author"),
                        mf.getMainAttributes().getValue("Fork-Plugin-Description")
                );

                plugin.setDescription(desc);

                ForkPluginManager.getInstance().register(plugin);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
