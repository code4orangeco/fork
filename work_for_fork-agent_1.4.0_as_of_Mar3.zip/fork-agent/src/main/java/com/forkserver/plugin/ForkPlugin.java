package com.forkserver.plugin;

public interface ForkPlugin {
    void onEnable();
    void onTick();

    void setDescription(ForkPluginDescription description);
    ForkPluginDescription getDescription();
}
