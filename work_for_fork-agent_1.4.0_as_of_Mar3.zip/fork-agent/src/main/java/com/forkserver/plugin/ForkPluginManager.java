package com.forkserver.plugin;

import com.forkserver.events.ForkEventBus;
import java.util.ArrayList;
import java.util.List;

public class ForkPluginManager {

    private static final ForkPluginManager INSTANCE = new ForkPluginManager();
    public static ForkPluginManager getInstance() { return INSTANCE; }

    private final List<ForkPlugin> plugins = new ArrayList<>();
    private final ForkEventBus eventBus = new ForkEventBus();

    public ForkEventBus getEventBus() { return eventBus; }

    public void register(ForkPlugin plugin) {
        plugins.add(plugin);
        plugin.onEnable();
    }

    public void onTick() {
        for (ForkPlugin plugin : plugins) {
            plugin.onTick();
        }
    }
}
