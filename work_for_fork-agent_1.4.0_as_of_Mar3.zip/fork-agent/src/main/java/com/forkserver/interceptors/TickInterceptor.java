package com.forkserver.interceptors;

import com.forkserver.plugin.ForkPluginManager;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;

public class TickInterceptor implements ClassFileTransformer {

    @Override
    public byte[] transform(Module module, ClassLoader loader, String className,
                            Class<?> classBeingRedefined, ProtectionDomain protectionDomain,
                            byte[] classfileBuffer) {

        if (className != null && className.contains("MinecraftServer")) {
            ForkPluginManager.getInstance().onTick();
        }

        return classfileBuffer;
    }
}
