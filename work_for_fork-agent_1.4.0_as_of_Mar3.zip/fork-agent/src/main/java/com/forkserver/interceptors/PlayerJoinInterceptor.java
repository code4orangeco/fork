package com.forkserver.interceptors;

import com.forkserver.plugin.ForkPluginManager;
import com.forkserver.events.PlayerJoinEvent;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;

public class PlayerJoinInterceptor implements ClassFileTransformer {

    @Override
    public byte[] transform(Module module, ClassLoader loader, String className,
                            Class<?> classBeingRedefined, ProtectionDomain protectionDomain,
                            byte[] classfileBuffer) {

        if (className != null && className.contains("Player")) {
            ForkPluginManager.getInstance()
                    .getEventBus()
                    .fire(new PlayerJoinEvent("UnknownPlayer"));
        }

        return classfileBuffer;
    }
}
