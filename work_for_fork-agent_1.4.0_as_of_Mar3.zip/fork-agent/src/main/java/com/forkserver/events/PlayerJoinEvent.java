package com.forkserver.events;

public class PlayerJoinEvent implements ForkEvent {

    private final String playerName;

    public PlayerJoinEvent(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerName() {
        return playerName;
    }
}
