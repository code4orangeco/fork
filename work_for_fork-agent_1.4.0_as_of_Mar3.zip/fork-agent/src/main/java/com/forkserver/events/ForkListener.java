package com.forkserver.events;

public interface ForkListener<T extends ForkEvent> {
    void handle(T event);
}
