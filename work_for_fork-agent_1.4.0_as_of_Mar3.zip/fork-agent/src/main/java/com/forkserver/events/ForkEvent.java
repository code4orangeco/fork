package com.forkserver.events;

public interface ForkEvent {}
