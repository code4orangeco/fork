package com.example.forkagent.events;

public interface ForkEvent {}
