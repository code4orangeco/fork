package com.example.forkagent.events;

public class PlayerJoinEvent implements ForkEvent {
    private final Object player;

    public PlayerJoinEvent(Object player) {
        this.player = player;
    }

    public Object getPlayer() {
        return player;
    }
}
