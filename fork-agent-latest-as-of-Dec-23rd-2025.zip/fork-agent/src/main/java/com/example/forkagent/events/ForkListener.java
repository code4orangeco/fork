package com.example.forkagent.events;

public interface ForkListener<T extends ForkEvent> {
    void handle(T event);
}
