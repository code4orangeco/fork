package com.example.forkagent.events;

import java.util.*;

public class ForkEventBus {
    private final Map<Class<?>, List<ForkListener<?>>> listeners = new HashMap<>();

    public <T extends ForkEvent> void register(Class<T> eventClass, ForkListener<T> listener) {
        listeners.computeIfAbsent(eventClass, k -> new ArrayList<>()).add(listener);
    }

    public <T extends ForkEvent> void fire(T event) {
        List<ForkListener<?>> list = listeners.get(event.getClass());
        if (list != null) {
            for (ForkListener<?> listener : list) {
                ((ForkListener<T>) listener).handle(event);
            }
        }
    }
}
