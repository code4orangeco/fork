package com.example.forkagent;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class ForkPluginLoader {
    public void loadAll() {
        File dir = new File("fork-plugins");
        if (!dir.exists()) dir.mkdirs();

        File[] jars = dir.listFiles((d, n) -> n.endsWith(".jar"));
        if (jars == null) return;

        for (File jar : jars) {
            try (JarFile jf = new JarFile(jar)) {
                Manifest mf = jf.getManifest();
                if (mf == null) continue;

                String mainClass = mf.getMainAttributes().getValue("Fork-Plugin-Class");
                if (mainClass == null) continue;

                URLClassLoader cl = new URLClassLoader(new URL[]{jar.toURI().toURL()});
                Class<?> clazz = cl.loadClass(mainClass);
                Object instance = clazz.getDeclaredConstructor().newInstance();

                if (instance instanceof ForkPlugin plugin)
                    ForkPluginManager.getInstance().registerPlugin(plugin);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
