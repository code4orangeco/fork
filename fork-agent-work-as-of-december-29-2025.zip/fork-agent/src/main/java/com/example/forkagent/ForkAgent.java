package com.example.forkagent;

import com.example.forkagent.interceptors.TickInterceptor;
import com.example.forkagent.interceptors.PlayerJoinInterceptor;
import com.example.forkagent.config.ForkConfig;

import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.matcher.ElementMatchers;
import net.bytebuddy.implementation.MethodDelegation;
import net.bytebuddy.implementation.SuperMethodCall;
import net.bytebuddy.utility.JavaModule;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;

public class ForkAgent {

    public static void premain(String args, Instrumentation inst) {

        // Load config before anything else
        ForkConfig.load(new File("fork.yml"));

        // Load all plugins before hooking anything
        new ForkPluginLoader().loadAll();

        //
        // 1. Hook MinecraftServer#tick
        //
        new AgentBuilder.Default()
            .type(ElementMatchers.nameEndsWith("MinecraftServer"))
            .transform(new AgentBuilder.Transformer() {
                @Override
                public DynamicType.Builder<?> transform(
                        DynamicType.Builder<?> builder,
                        TypeDescription typeDescription,
                        ClassLoader classLoader,
                        JavaModule module,
                        ProtectionDomain protectionDomain) {

                    return builder
                        .method(ElementMatchers.named("tick"))
                        .intercept(MethodDelegation.to(TickInterceptor.class)
                        .andThen(SuperMethodCall.INSTANCE));
                }
            })
            .installOn(inst);

        //
        // 2. Hook PlayerList#placeNewPlayer (Player Join Event)
        //
        new AgentBuilder.Default()
            .type(ElementMatchers.nameEndsWith("PlayerList"))
            .transform(new AgentBuilder.Transformer() {
                @Override
                public DynamicType.Builder<?> transform(
                        DynamicType.Builder<?> builder,
                        TypeDescription typeDescription,
                        ClassLoader classLoader,
                        JavaModule module,
                        ProtectionDomain protectionDomain) {

                    return builder
                        .method(ElementMatchers.named("placeNewPlayer"))
                        .intercept(MethodDelegation.to(PlayerJoinInterceptor.class)
                        .andThen(SuperMethodCall.INSTANCE));
                }
            })
            .installOn(inst);
    }
}
