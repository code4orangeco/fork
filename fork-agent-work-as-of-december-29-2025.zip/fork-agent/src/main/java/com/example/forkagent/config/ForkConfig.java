package com.example.forkagent.config;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.util.Map;
import org.yaml.snakeyaml.Yaml;

public class ForkConfig {

    // Performance
    public static int maxEntityTickBatch;
    public static boolean asyncPathfinding;
    public static boolean optimizedHoppers;
    public static boolean optimizedRedstone;

    // Experimental
    public static boolean enableExperimentalFeatures;
    public static boolean asyncEntityTracking;
    public static boolean fastBlockUpdates;

    // Logging
    public static int slowTickThresholdMs;
    public static int slowEventThresholdMs;
    public static boolean logChunkLoads;
    public static boolean logChunkUnloads;
    public static boolean logEntitySpawns;

    // Debug
    public static boolean enableDebugCommands;
    public static int tpsPrecision;
    public static int heatmapResolution;
    public static boolean showEntityCounts;

    private static void writeDefaultConfig(File file) throws Exception {
        String defaults =
                "performance:\n" +
                "  max-entity-tick-batch: 50\n" +
                "  async-pathfinding: false\n" +
                "  optimized-hoppers: false\n" +
                "  optimized-redstone: false\n" +
                "\n" +
                "experimental:\n" +
                "  enable-experimental-features: false\n" +
                "  async-entity-tracking: false\n" +
                "  fast-block-updates: false\n" +
                "\n" +
                "logging:\n" +
                "  slow-tick-threshold-ms: 5\n" +
                "  slow-event-threshold-ms: 2\n" +
                "  log-chunk-loads: false\n" +
                "  log-chunk-unloads: false\n" +
                "  log-entity-spawns: false\n" +
                "\n" +
                "debug:\n" +
                "  enable-debug-commands: true\n" +
                "  tps-precision: 2\n" +
                "  heatmap-resolution: 16\n" +
                "  show-entity-counts: true\n";

        file.getParentFile().mkdirs();
        Files.writeString(file.toPath(), defaults);
        System.out.println("[ForkConfig] Created default fork.yml");
    }

    @SuppressWarnings("unchecked")
    public static void load(File file) {
        try {
            if (!file.exists()) {
                writeDefaultConfig(file);
            }

            Yaml yaml = new Yaml();
            Map<String, Object> root = yaml.load(new FileInputStream(file));

            Map<String, Object> performance = (Map<String, Object>) root.getOrDefault("performance", Map.of());
            Map<String, Object> experimental = (Map<String, Object>) root.getOrDefault("experimental", Map.of());
            Map<String, Object> logging = (Map<String, Object>) root.getOrDefault("logging", Map.of());
            Map<String, Object> debug = (Map<String, Object>) root.getOrDefault("debug", Map.of());

            maxEntityTickBatch = (int) performance.getOrDefault("max-entity-tick-batch", 50);
            asyncPathfinding = (boolean) performance.getOrDefault("async-pathfinding", false);
            optimizedHoppers = (boolean) performance.getOrDefault("optimized-hoppers", false);
            optimizedRedstone = (boolean) performance.getOrDefault("optimized-redstone", false);

            enableExperimentalFeatures = (boolean) experimental.getOrDefault("enable-experimental-features", false);
            asyncEntityTracking = (boolean) experimental.getOrDefault("async-entity-tracking", false);
            fastBlockUpdates = (boolean) experimental.getOrDefault("fast-block-updates", false);

            slowTickThresholdMs = (int) logging.getOrDefault("slow-tick-threshold-ms", 5);
            slowEventThresholdMs = (int) logging.getOrDefault("slow-event-threshold-ms", 2);
            logChunkLoads = (boolean) logging.getOrDefault("log-chunk-loads", false);
            logChunkUnloads = (boolean) logging.getOrDefault("log-chunk-unloads", false);
            logEntitySpawns = (boolean) logging.getOrDefault("log-entity-spawns", false);

            enableDebugCommands = (boolean) debug.getOrDefault("enable-debug-commands", true);
            tpsPrecision = (int) debug.getOrDefault("tps-precision", 2);
            heatmapResolution = (int) debug.getOrDefault("heatmap-resolution", 16);
            showEntityCounts = (boolean) debug.getOrDefault("show-entity-counts", true);

            System.out.println("[ForkConfig] Loaded fork.yml successfully.");

        } catch (Exception e) {
            System.out.println("[ForkConfig] Failed to load fork.yml");
            e.printStackTrace();
        }
    }
}
