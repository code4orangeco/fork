package com.example.forkagent.interceptors;

import com.example.forkagent.ForkPluginManager;
import com.example.forkagent.events.PlayerJoinEvent;

public class PlayerJoinInterceptor {
    public static void intercept(Object player) {
        ForkPluginManager.getInstance().getEventBus().fire(new PlayerJoinEvent(player));
    }
}
