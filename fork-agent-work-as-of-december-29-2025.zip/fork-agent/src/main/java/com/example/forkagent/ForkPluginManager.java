package com.example.forkagent;

import com.example.forkagent.events.ForkEventBus;
import java.util.ArrayList;
import java.util.List;

public class ForkPluginManager {

    private static final ForkPluginManager INSTANCE = new ForkPluginManager();
    public static ForkPluginManager getInstance() { return INSTANCE; }

    private final List<ForkPlugin> plugins = new ArrayList<>();

    // Event bus for all plugin events
    private final ForkEventBus eventBus = new ForkEventBus();
    public ForkEventBus getEventBus() { return eventBus; }

    // Register plugin and call onEnable
    public void registerPlugin(ForkPlugin plugin) {
        plugins.add(plugin);
        plugin.onEnable();
    }

    // Called every tick by TickInterceptor
    public void onTick() {
        for (ForkPlugin plugin : plugins) {
            plugin.onTick();
        }
    }
}
