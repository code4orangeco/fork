package com.example.forkagent.interceptors;

import com.example.forkagent.ForkPluginManager;

public class TickInterceptor {
    public static void intercept() {
        ForkPluginManager.getInstance().onTick();
    }
}
